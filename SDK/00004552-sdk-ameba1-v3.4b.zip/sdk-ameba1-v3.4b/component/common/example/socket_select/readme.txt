LWIP SOCKET SELECT EXAMPLE

Description:
TCP server listens on port 5000 and handle socket by select().

Configuration:
[platform_opts.h]
    #define CONFIG_EXAMPLE_SOCKET_SELECT    1

Execution:
Can make automatical Wi-Fi connection when booting by using wlan fast connect example.
A socket select example thread will be started automatically when booting.

