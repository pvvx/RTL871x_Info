#ifndef EXAMPLE_MCAST_H
#define EXAMPLE_MCAST_H

void example_mcast(void);

#endif /* EXAMPLE_MCAST_H */
