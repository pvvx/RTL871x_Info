#ifndef __EXAMPLE_ENTRY_H__
#define __EXAMPLE_ENTRY_H__


void example_entry(void);
void pre_example_entry(void);

#endif //#ifndef __EXAMPLE_ENTRY_H__
